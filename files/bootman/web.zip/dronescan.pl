#!/usr/bin/perl

use strict;
use Net::OpenSSH;

my @drone = (1..21);
for my $i (0 .. $#drone) {
    $drone[$i] = "drone".$drone[$i];
}
push(@drone, "192.168.2.47");

my ($login, $uname, $release);

for my $i (0 .. $#drone) {
    my $ssh = Net::OpenSSH->new(
        $drone[$i],
        user => "timesys",
        password => "time123"
    );

    my ($mem, $meminfo_err) = $ssh->capture2("cat /proc/meminfo");
    my ($archi, $archi_err) = $ssh->capture2("uname -m");
    my ($kernel, $kern_err) = $ssh->capture2("uname -r");
    my ($hostname, $ho_err) = $ssh->capture2("echo \$HOSTNAME");

    # clean up output
    $mem =~ m/MemTotal:\s+(\d+ kB)/;
    $mem = $1;
    $archi =~ s/\n//;
    $kernel =~ s/\n//;
    $hostname =~ s/\n//;

    # get release
    my ($release, $rel_err, $release_name, $release_vers);
    if (-f "/etc/os-release") {
        ($release, $rel_err) = $ssh->capture2("cat /etc/os-release");
        $release =~ m/NAME="?(\w+)"?/;
        $release_name = $1; 
        $release =~ m/VERSION="?([\w\.]+)"?/;
        $release_vers = $1; 
        $release = "$release_name $release_vers (Linux $kernel)";
    }

    print "$hostname ($archi) $mem RAM\n";
    if ($release) {
        print "$release\n";
    }
    print "$uname\n";
}
