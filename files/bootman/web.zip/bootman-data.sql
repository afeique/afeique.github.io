--
-- PostgreSQL database dump
--

-- Dumped from database version 9.1.14
-- Dumped by pg_dump version 9.1.14
-- Started on 2015-01-30 14:48:39 EST

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

--
-- TOC entry 1923 (class 0 OID 55461)
-- Dependencies: 162 1929
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY inventory (id, board, hostname, uname, telnet_addr, telnet_port, rack, port, "time", verified) FROM stdin;
4	am3517_evm-1	am3517_evm\r	Linux am3517_evm 2.6.37-ts-armv7l #1 Fri Jun 6 12:30:42 IST 2014 armv7l GNU/Linux\r	192.168.99.21	2003	1	3	1422641366	\N
5	amcc460ex-1			192.168.99.22	2012	2	12	1422641409	\N
6	at501-1			192.168.99.27	2001	7	1	1422641410	\N
7	at501-2			192.168.99.27	2002	7	2	1422641412	\N
8	at91cap9a_dk-1			192.168.99.24	2012	4	12	1422641456	\N
9	at91rm9200_ek-1			192.168.99.23	2005	3	5	1422641499	\N
10	at91sam9260_ek-1	at91sam9260_ek\r	Linux at91sam9260_ek 2.6.36-ts-armv5l #1 PREEMPT Tue Jun 4 18:54:40 EDT 2013 armv5tejl GNU/Linux\r	192.168.99.23	2003	3	3	1422641502	\N
11	at91sam9261_ek-1			192.168.99.24	2005	4	5	1422641545	\N
12	at91sam9263_ek-1	at91sam9263_ek\r	Linux at91sam9263_ek 2.6.38-ts-armv5l #1 PREEMPT Thu Nov 7 13:00:06 EST 2013 armv5tejl GNU/Linux\r	192.168.99.23	2011	3	11	1422641548	\N
13	at91sam9g10_ek-1			192.168.99.22	2009	2	9	1422641591	\N
14	at91sam9g15_ek-1	at91sam9g15_ek\r	Linux at91sam9g15_ek 2.6.39-ts-armv5l #1 Thu Jun 7 12:51:58 EDT 2012 armv5tejl GNU/Linux\r	192.168.99.26	2006	6	6	1422641595	\N
15	at91sam9g20_ek-1			192.168.99.24	2011	4	11	1422641638	\N
16	at91sam9g25_ek-1		U-Boot> 	192.168.99.25	2001	5	1	1422641681	\N
17	at91sam9g35_ek-1	at91sam9x35_ek\r	Linux at91sam9x35_ek 3.10.0-ts-armv5l #1 Thu Oct 16 02:11:40 EDT 2014 armv5tejl GNU/Linux\r	192.168.99.26	2007	6	7	1422641684	\N
18	at91sam9g45_ek-1			192.168.99.22	2004	2	4	1422641727	\N
19	at91sam9m10_ek_es-1	at91sam9m10_ek_es\r	Linux at91sam9m10_ek_es 2.6.36-ts-armv5l #4 PREEMPT Tue Sep 30 17:29:16 IST 2014 armv5tejl GNU/Linux\r	192.168.99.21	2009	1	9	1422641730	\N
20	at91sam9rl_ek-1			192.168.99.24	2013	4	13	1422641773	\N
21	at91sama5d36_ek-1			192.168.99.27	2005	7	5	1422641816	\N
22	beagleboardxm-1	beagleboardxm\r	Linux beagleboardxm 3.0.17-ts-armv7l #4 Wed Oct 9 10:27:37 EDT 2013 armv7l GNU/Linux\r	192.168.99.26	2002	6	2	1422641819	\N
23	beaglebone_black-1			192.168.99.27	2011	7	11	1422641820	\N
24	ccwmx51js-1	\rCCWMX51 # uname -a	\rCCWMX51 # \r	192.168.99.21	2011	1	11	1422641824	\N
25	ccwmx53js-1	timesys\r	Linux timesys 2.6.35-ts-armv7l #1 Mon Aug 4 18:00:22 EDT 2014 armv7l GNU/Linux\r	192.168.99.26	2011	6	11	1422641827	\N
26	certes-1			192.168.99.21	2016	1	16	1422641870	\N
27	core2duo-1			192.168.99.22	2015	2	15	1422641913	\N
28	customer_board-1			6	1	6	1	1422641914	\N
29	dm3730_evm-1	dm3730_evm\r	Linux dm3730_evm 2.6.37-ts-armv7l #2 Wed Nov 12 13:28:51 EST 2014 armv7l GNU/Linux\r	192.168.99.25	2004	5	4	1422641917	\N
30	dm3730_zoom_som_lv-1			192.168.99.25	2005	5	5	1422641919	\N
31	dm3730_zoom_torpedo-1			192.168.99.25	2006	5	6	1422641920	\N
32	dm6446_dvevm-1			192.168.99.23	2013	3	13	1422641963	\N
33	dm8148_evm-1	dm8148_evm\r	Linux dm8148_evm 2.6.37-ts-armv7l #1 Tue Jun 10 12:22:18 IST 2014 armv7l GNU/Linux\r	192.168.99.25	2011	5	11	1422641966	\N
34	en700-1			192.168.99.23	2007	3	7	1422642009	\N
35	ep8572a-1			192.168.99.24	2010	4	10	1422642010	\N
36	i.MX27Litekit-1			192.168.99.24	2014	4	14	1422642054	\N
37	i.MX28-1			192.168.99.26	2003	6	3	1422642097	\N
38	i.MX31Litekit-1	iMX31Litekit\r	Linux iMX31Litekit 2.6.24-ts-armv6l-335-g47af517 #1 PREEMPT Fri Apr 11 15:17:20 EDT 2014 armv6l GNU/Linux\r	192.168.99.24	2003	4	3	1422642100	\N
39	i.MX35pdk-1	i.MX35pdk\r	Linux i.MX35pdk 2.6.31-ts-armv6l #1 PREEMPT Mon May 20 21:25:47 EDT 2013 armv6l GNU/Linux\r	192.168.99.21	2014	1	14	1422642103	\N
40	i.MX50evk-1			192.168.99.22	2011	2	11	1422642146	\N
41	i.MX51evk-1	iMX51evk\r	Linux iMX51evk 2.6.35-ts-armv7l #1 PREEMPT Mon Nov 11 00:03:58 EST 2013 armv7l GNU/Linux\r	192.168.99.21	2010	1	10	1422642150	\N
42	i.MX53start-1	iMX53start\r	Linux iMX53start 2.6.35-ts-armv7l #1 PREEMPT Mon Mar 10 10:28:23 IST 2014 armv7l GNU/Linux\r	192.168.99.25	2008	5	8	1422642153	\N
43	i.MX6QSABRELite-1			192.168.99.26	2013	6	13	1422642196	\N
44	ixp435-1			192.168.99.22	2005	2	5	1422642197	\N
45	malta-1			192.168.99.24	2007	4	7	1422642240	\N
46	mcf5485-evb-1			192.168.99.25	2007	5	7	1422642283	\N
47	mityarm_335x-1	U-Boot# uname -a\r	U-Boot# \r	192.168.99.22	2014	2	14	1422642286	\N
49	mpc8272_ads-1			192.168.99.22	2006	2	6	1422642332	\N
50	mpc8308_nsg-1	mpc8308_nsg\r	Linux mpc8308_nsg 2.6.29-ts-powerpc #1 Thu May 9 22:14:15 EDT 2013 ppc GNU/Linux\r	192.168.99.26	2012	6	12	1422642335	\N
51	mpc8308e_rdb-1			192.168.99.26	2004	6	4	1422642336	\N
52	mpc8313e_rdb-1		=> 	192.168.99.23	2014	3	14	1422642380	\N
53	mpc8536ds-1	mpc8536a_dk\r	Linux mpc8536a_dk 3.0.34-ts-powerpc-rt55 #1 Mon May 20 20:57:40 EDT 2013 ppc GNU/Linux\r	192.168.99.23	2016	3	16	1422642383	\N
54	mpc8544ds-1	mpc8544ds\r	Linux mpc8544ds 3.0.34-ts-powerpc-rt55 #1 Wed Nov 7 15:07:58 EST 2012 ppc GNU/Linux\r	192.168.99.24	2016	4	16	1422642386	\N
55	mpc8548cds-1			192.168.99.23	2008	3	8	1422642429	\N
56	mpc8560ads-1			192.168.99.22	2007	2	7	1422642472	\N
57	mpc8572ds-1	mpc8572ds\r	Linux mpc8572ds 3.0.34-ts-powerpc-rt55 #1 SMP Tue Jan 1 05:28:24 EST 2013 ppc GNU/Linux\r	192.168.99.24	2008	4	8	1422642476	\N
58	mpc8641_hpcn-1	mpc8641_hpcn\r	Linux mpc8641_hpcn 2.6.28-ts-powerpc #1 SMP Fri Mar 22 22:55:43 EDT 2013 ppc GNU/Linux\r	192.168.99.22	2008	2	8	1422642479	\N
59	mpc885_ads-1			192.168.99.22	2001	2	1	1422642522	\N
60	mv78200_a1-1	mv78200_a1\r	Linux mv78200_a1 2.6.31-ts-armv5l #1 Mon May 20 21:38:12 EDT 2013 armv5tel GNU/Linux\r	192.168.99.25	2010	5	10	1422642959	\N
61	nexus1450-1			192.168.99.25	2003	5	3	1422643002	\N
62	nitrogen6x-1			192.168.99.22	2013	2	13	1422643045	\N
63	omap35x_som_lv-1			192.168.99.24	2006	4	6	1422643048	\N
64	omap35x_torpedo-1			192.168.99.21	2012	1	12	1422643091	\N
1	AMCC405GP-1			192.168.99.22	2016	2	16	1422647114	\N
2	am1808_evm-1	am1808_evm\r	Linux am1808_evm 3.3.0-ts-armv5l #1 PREEMPT Mon Jun 9 14:59:14 IST 2014 armv5tejl GNU/Linux\r	192.168.99.25	2013	5	13	1422647118	\N
3	am335x_evm-1	am335x_evm\r	Linux am335x_evm 3.14.26-ts-armv7l #1 SMP Wed Dec 31 10:57:17 EST 2014 armv7l GNU/Linux\r	192.168.99.25	2015	5	15	1422647121	\N
65	omap3_evm-1			192.168.99.23	2015	3	15	1422643092	\N
66	omapl138_evm-1		U-Boot > 	192.168.99.21	2002	1	2	1422643136	\N
67	overo_evm-1	overo\r	Linux overo 2.6.34 #1 Wed Oct 20 10:22:48 PDT 2010 armv7l GNU/Linux\r	192.168.99.27	2010	7	10	1422643139	\N
68	p1020_rdb-1			192.168.99.22	2010	2	10	1422643182	\N
69	p2020_rdb-1			192.168.99.21	2005	1	5	1422643225	\N
70	p3041ds-1			192.168.99.21	2007	1	7	1422643226	\N
71	p4080ds_pb-1	p4080ds_pb\r	Linux p4080ds_pb 3.0.34-ts-powerpc-rt55 #2 SMP PREEMPT RT Thu Dec 18 10:15:45 IST 2014 ppc GNU/Linux\r	192.168.99.26	2008	6	8	1422643230	\N
72	pcm052-1			192.168.99.23	2006	3	6	1422643273	\N
73	premierwave_xn-1			192.168.99.27	2012	7	12	1422643275	\N
74	quartz-1			192.168.99.24	2004	4	4	1422643318	\N
75	rsk_rza1-1	rsk_rza1\r	Linux rsk_rza1 3.14.0-ts-armv7l #7 Mon Jan 12 13:36:23 EST 2015 armv7l GNU/Linux\r	192.168.99.27	2004	7	4	1422643321	\N
76	rts7751r2d-1			192.168.99.24	2002	4	2	1422643365	\N
77	s2_nanonode_v2-1			192.168.99.27	2007	7	7	1422643367	\N
78	sabre_sdb-1			192.168.99.27	2006	7	6	1422643368	\N
79	toyon_nitrogen6x-1			192.168.99.23	2012	3	12	1422643411	\N
80	twr_vf600-1	pcm052\r	Linux pcm052 3.13.9-00015-g607411c #237 Thu Jan 22 13:43:31 EST 2015 armv7l GNU/Linux\r	192.168.99.22	2003	2	3	1422643414	\N
81	wandboard_dual-1	wandboard_dual\r	Linux wandboard_dual 3.0.35-ts-armv7l #2 SMP PREEMPT Fri May 23 10:56:51 EDT 2014 armv7l GNU/Linux\r	192.168.99.23	2004	3	4	1422643418	\N
83	wds3-1			192.168.99.21	2013	1	13	1422643504	\N
84	zedboard-1			192.168.99.27	2003	7	3	1422643506	\N
48	mitydsp_l138f-1	mitydsp_l138f\r	Linux mitydsp_l138f 2.6.34-ts-armv5l #1 PREEMPT Thu May 30 17:16:13 EDT 2013 armv5tejl GNU/Linux\r	192.168.99.21	2001	1	1	1422642289	1422643917
82	wds2-1			192.168.99.21	2006	1	6	1422643461	1422643987
\.


--
-- TOC entry 1933 (class 0 OID 0)
-- Dependencies: 163
-- Name: inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('inventory_id_seq', 1, false);


--
-- TOC entry 1925 (class 0 OID 55470)
-- Dependencies: 164 1923 1929
-- Data for Name: logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY logs (id, inventory_id, hostname, uname_before, uname_after, kernel_image_uri, rfs_tarball_uri, devicetree_uri, "time") FROM stdin;
85	1				http://afeique.com/timesys/zedboard/uImage-3.13-ts-armv7l	http://afeique.com/timesys/zedboard/rfs/rootfs.tar.gz		1422646033
86	1	timesys\r	Linux timesys 2.6.35-ts-armv7l #1 Mon Aug 4 18:00:22 EDT 2014 armv7l GNU/Linux\r	Linux timesys 2.6.35-ts-armv7l #1 Mon Aug 4 18:00:22 EDT 2014 armv7l GNU/Linux\r	http://afeique.com/timesys/ccwmx53js/uImage-2.6.35-ts-armv7l	http://afeique.com/timesys/ccwmx53js/rfs/rootfs.tar.gz		1422646033
87	1	\rCCWMX51 # uname -a	\rCCWMX51 # \r	\rCCWMX51 # \r	http://afeique.com/timesys/ccwmx51js/uImage-2.6.35-ts-armv7l	http://afeique.com/timesys/ccwmx51js/rfs/rootfs.tar.gz		1422646033
88	1				http://afeique.com/timesys/nitrogen6x/uImage-3.10-ts-armv7l	http://afeique.com/timesys/nitrogen6x/rfs/rootfs.tar.gz		1422646033
\.


--
-- TOC entry 1934 (class 0 OID 0)
-- Dependencies: 161
-- Name: logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('logs_id_seq', 88, true);


--
-- TOC entry 1926 (class 0 OID 55477)
-- Dependencies: 165 1929
-- Data for Name: test; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY test (id, inventory_id) FROM stdin;
\.


--
-- TOC entry 1928 (class 0 OID 55482)
-- Dependencies: 167 1923 1929
-- Data for Name: uris; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY uris (id, inventory_id, kernel_image, rfs_tarball, devicetree) FROM stdin;
1	2			
2	3			
3	4			
4	1			
5	5			
6	6			
7	7			
8	8			
9	9			
10	10			
11	11			
12	12			
13	13			
14	14			
15	15			
16	16			
17	17			
18	18			
19	19			
20	20			
21	21			
22	22			
23	23			
24	24			
25	25			
26	26			
27	27			
28	28			
29	29			
30	30			
31	31			
32	32			
33	33			
34	34			
35	35			
36	36			
37	37			
38	38			
39	39			
40	40			
41	41			
42	42			
43	43			
44	44			
45	45			
46	46			
47	47			
48	48			
49	49			
50	51			
51	50			
52	52			
53	53			
54	54			
55	55			
56	56			
57	57			
58	58			
59	59			
60	60			
61	61			
62	62	http://afeique.com/timesys/nitrogen6x/ui		
63	63			
64	64			
65	65			
66	66			
67	67			
68	68			
69	69			
70	70			
71	71			
72	72			
73	73			
74	74			
75	75			
76	76			
77	77			
78	78			
79	79			
80	80			
81	81			
82	82			
83	83			
84	84			
\.


--
-- TOC entry 1935 (class 0 OID 0)
-- Dependencies: 166
-- Name: uris_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('uris_id_seq', 84, true);


-- Completed on 2015-01-30 14:48:39 EST

--
-- PostgreSQL database dump complete
--

