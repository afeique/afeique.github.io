--
-- PostgreSQL database dump
--

-- Dumped from database version 9.1.14
-- Dumped by pg_dump version 9.1.14
-- Started on 2015-01-30 12:55:10 EST

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- TOC entry 168 (class 3079 OID 11681)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 1929 (class 0 OID 0)
-- Dependencies: 168
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- TOC entry 162 (class 1259 OID 55228)
-- Dependencies: 5
-- Name: logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.logs_id_seq OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 163 (class 1259 OID 55245)
-- Dependencies: 1807 5
-- Name: inventory; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE inventory (
    id integer DEFAULT nextval('logs_id_seq'::regclass) NOT NULL,
    board character varying(255) NOT NULL,
    hostname character varying(255),
    uname character varying(255),
    telnet_addr character varying(15) NOT NULL,
    telnet_port integer NOT NULL,
    rack integer NOT NULL,
    port integer NOT NULL,
    time integer NOT NULL,
    verified integer
);


ALTER TABLE public.inventory OWNER TO postgres;

--
-- TOC entry 164 (class 1259 OID 55253)
-- Dependencies: 5
-- Name: inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE inventory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.inventory_id_seq OWNER TO postgres;

--
-- TOC entry 161 (class 1259 OID 55220)
-- Dependencies: 1806 5
-- Name: logs; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE logs (
    id integer DEFAULT nextval('logs_id_seq'::regclass) NOT NULL,
    inventory_id integer NOT NULL,
    hostname character varying(255),
    uname_before character varying(255),
    uname_after character varying(255),
    kernel_image_uri character varying(255) NOT NULL,
    rfs_tarball_uri character varying(255) NOT NULL,
    devicetree_uri character varying(255) NOT NULL,
    time integer NOT NULL
);


ALTER TABLE public.logs OWNER TO postgres;

--
-- TOC entry 167 (class 1259 OID 55301)
-- Dependencies: 5
-- Name: test; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE test (
    id integer NOT NULL,
    inventory_id integer
);


ALTER TABLE public.test OWNER TO postgres;

--
-- TOC entry 166 (class 1259 OID 55273)
-- Dependencies: 5
-- Name: uris_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE uris_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.uris_id_seq OWNER TO postgres;

--
-- TOC entry 165 (class 1259 OID 55268)
-- Dependencies: 1808 5
-- Name: uris; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE uris (
    id integer DEFAULT nextval('uris_id_seq'::regclass) NOT NULL,
    inventory_id integer NOT NULL,
    kernel_image character varying(255),
    rfs_tarball character varying,
    devicetree character varying(255)
);


ALTER TABLE public.uris OWNER TO postgres;

--
-- TOC entry 1813 (class 2606 OID 55329)
-- Dependencies: 163 163 1923
-- Name: inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (id);


--
-- TOC entry 1811 (class 2606 OID 55331)
-- Dependencies: 161 161 1923
-- Name: logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY logs
    ADD CONSTRAINT logs_pkey PRIMARY KEY (id);


--
-- TOC entry 1818 (class 2606 OID 55305)
-- Dependencies: 167 167 1923
-- Name: test_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY test
    ADD CONSTRAINT test_pkey PRIMARY KEY (id);


--
-- TOC entry 1816 (class 2606 OID 55339)
-- Dependencies: 165 165 1923
-- Name: uris_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY uris
    ADD CONSTRAINT uris_pkey PRIMARY KEY (id);


--
-- TOC entry 1809 (class 1259 OID 55355)
-- Dependencies: 161 1923
-- Name: fki_logs_inventory_id_fkey; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX fki_logs_inventory_id_fkey ON logs USING btree (inventory_id);


--
-- TOC entry 1814 (class 1259 OID 55300)
-- Dependencies: 165 1923
-- Name: fki_uris_inventory_id_fkey; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX fki_uris_inventory_id_fkey ON uris USING btree (inventory_id);


--
-- TOC entry 1819 (class 2606 OID 55350)
-- Dependencies: 163 161 1812 1923
-- Name: logs_inventory_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY logs
    ADD CONSTRAINT logs_inventory_id_fkey FOREIGN KEY (inventory_id) REFERENCES inventory(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 1820 (class 2606 OID 55340)
-- Dependencies: 165 1812 163 1923
-- Name: uris_inventory_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY uris
    ADD CONSTRAINT uris_inventory_id_fkey FOREIGN KEY (inventory_id) REFERENCES inventory(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 1928 (class 0 OID 0)
-- Dependencies: 5
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


-- Completed on 2015-01-30 12:55:10 EST

--
-- PostgreSQL database dump complete
--

