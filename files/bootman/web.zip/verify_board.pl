#!/usr/bin/perl

use strict;
use Getopt::Long;
use Pod::Usage;
use DBI;

my ($help, $board);
my ($db_type, $db_host, $db_name, $db_user, $db_pass);

$db_type = "Pg";
$db_host = "localhost";
$db_name = "boardfarm";
$db_user = "postgres";
$db_pass = 'a';

GetOptions( 
    "help|?"        => \$help,
    "board|b=s"     => \$board
) or pod2usage({'-verbose' => 0, '-exitval' => 1});

pod2usage({'-verbose' => 1, '-exitval' => 0}) if $help;
pod2usage({'-verbose' => 1, '-exitval' => 0}) unless $board;

=head1 DESCRIPTION

Connects to database and marks the specified board as having been physically verified.

=back

=head1 OPTIONS

=over

=item --help, -?

Prints help and usage information.

=item --board, -b

Name of board to mark as verified.

=back

=cut

# connect to database
my $dbh = DBI->connect("dbi:$db_type:dbname=$db_name;host=$db_host", $db_user, $db_pass);

my $t = time();
my $q = $dbh->prepare("UPDATE inventory SET verified=$t WHERE board=?");
$q->bind_param(1, $board);
$q->execute() or die $DBI::errstr;
$dbh->disconnect();

print "verified $board\n";

