#!/bin/bash

if [ -z "$1" ]; then
    echo "$(tput bold)USAGE$(tput sgr0)"
    echo -e "\t$0 IP PORT\n"
    echo "$(tput bold)DESCRIPTION$(tput sgr0)"
    echo -e "\tTelnets into board via provided terminal server IP and PORT, then attempts to return hostname.\n"
    echo
    exit 1
fi

expect -c "
    set timeout 10
    spawn telnet $1 $2
    expect {
        \"Are you sure you want to continue connecting (yes/no)? \" { send yes\r; exp_continue }
        \"Escape character is '^]'.\" { send \r }
        \"Unable to connect to remote host: Connection refused\" { exit 0 }
        timeout { exit 0 }
    }

    expect \"#\" { send \"hostname\r\" }
    sleep 1
    expect \"#\" { send \"uname -a\r\" }
    sleep 1
    expect \"#\" { send \035 }
    expect \"telnet> \" { send quit\r }
" 
# \035 = \x1d
