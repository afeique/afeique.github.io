#!/usr/bin/perl

use strict;
my @h = `./shellcheck.sh $ARGV[0] $ARGV[1]`;
#my @h = `./shellcheck.sh 192.168.99.21 2003`;
#my @h = `./shellcheck.sh 192.168.99.25 2013`;
for my $i (0 .. $#h) {
    if ($h[$i] =~ /hostname/) {
        if ($h[$i+1] =~ /^[a-zA-Z]/) {
            print $h[$i+1];
        }
        if ($h[$i+2] =~ /^[a-zA-Z]/) {
            print $h[$i+2];
        }
    }
}
