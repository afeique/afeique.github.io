define(function() {
	return (/\?/);
});
