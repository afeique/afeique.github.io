define(function() {
	return (/\S+/g);
});
