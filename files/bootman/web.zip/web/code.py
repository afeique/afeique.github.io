#!/usr/bin/python

from datetime import datetime
from time import time
import json

# uses web.py
# see http://webpy.org/
import web
view = web.template.render("views/", base="layout")

db = web.database(dbn="postgres", host="localhost", db="bootman", user="postgres", pw='a')

urls = (
    '/', "index",
    "/uris", "uris",
    "/verify", "verify",
    "/verify-json", "verifyJSON",
    "/unverify-json", "unverifyJSON"
)

class index:
    def GET(self):
        boards = db.query("SELECT * FROM inventory ORDER BY rack,port ASC").list()
        for b in boards:
            if b.verified:
                b.verified = datetime.fromtimestamp(b.verified).strftime('%B %d, %Y at %I:%M %p')
        timestamp = datetime.fromtimestamp(int(boards[0].time)).strftime('%B %d, %Y at %I:%M %p')
        return view.inventory(boards, timestamp)

class uris:
    def GET(self):
        uris = db.query("SELECT i.id,i.board,u.inventory_id,u.kernel_image,u.rfs_tarball,u.devicetree FROM inventory i LEFT JOIN uris u ON i.id=u.inventory_id ORDER BY i.board ASC").list();
        return view.uris(uris, updated=False)

    def POST(self):
        uris = web.input()
        boards = db.query("SELECT i.id,i.board,u.id AS imageuri_id FROM inventory i LEFT JOIN uris u ON i.id=u.inventory_id ORDER BY board ASC").list()
        for b in boards:
            inventory_id = b.id;
            kernel_image = getattr(uris, "kernel_image" + str(b.id));
            rfs_tarball = getattr(uris, "rfs_tarball" + str(b.id));
            devicetree = getattr(uris, "devicetree" + str(b.id));
            vals = {'k':kernel_image, 'r':rfs_tarball, 'd':devicetree, 'i':inventory_id}
            if b.imageuri_id:
                db.query("UPDATE uris SET kernel_image=$k,rfs_tarball=$r,devicetree=$d WHERE inventory_id=$i", vars=vals)
            else:
                db.query("INSERT INTO uris (kernel_image,rfs_tarball,devicetree,inventory_id) VALUES ($k,$r,$d,$i)", vars=vals)

        uris = db.query("SELECT i.id,i.board,u.inventory_id,u.kernel_image,u.rfs_tarball,u.devicetree FROM inventory i LEFT JOIN uris u ON i.id=u.inventory_id ORDER BY i.board ASC").list();
        return view.uris(uris, updated=True)


class verify:
    def GET(self):
        boards = db.query("SELECT * FROM inventory ORDER BY rack,port ASC").list()
        for b in boards:
            if b.verified:
                b.verified = datetime.fromtimestamp(b.verified).strftime('%B %d, %Y at %I:%M %p')

        return view.verify(boards)

class verifyJSON:
    def GET(self):
        web.header('Content-Type', 'application/json')
        data = web.input(board_id=False)
        if data.board_id is not False:
            r = db.query("SELECT * FROM inventory WHERE id=$i", vars={'i':data.board_id}).list()
            if r:
                board = r[0]
            else:
                return json.dumps({"success": 0, "error": "Invalid board identifier."})
            if board:
                t = int(time())
                db.query("UPDATE inventory SET verified=$t WHERE id=$i", vars={'t':t, 'i':data.board_id})
                f_t = datetime.fromtimestamp(t).strftime('%B %d, %Y at %I:%M %p')
                return json.dumps({"success": 1, "verified": f_t})

class unverifyJSON:
    def GET(self):
        web.header('Content-Type', 'application/json')
        data = web.input(board_id=False)
        if data.board_id is not False:
            r = db.query("SELECT * FROM inventory WHERE id=$i", vars={'i':data.board_id}).list()
            if r:
                board = r[0]
            else:
                return json.dumps({"success": 0, "error": "Invalid board identifier."})
            if board:
                t = int(time())
                db.query("UPDATE inventory SET verified=NULL WHERE id=$i", vars={'t':t, 'i':data.board_id})
                return json.dumps({"success": 1})



if __name__ == "__main__":
    app = web.application(urls, globals())
    app.run()

